export default function FeaturedItem(props) {
    return <div>
        <p>I should display the feature that was passed to me...</p>
    </div>
}