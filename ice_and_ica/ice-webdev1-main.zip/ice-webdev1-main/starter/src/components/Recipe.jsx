import { useState } from "react";
import { Button, Card } from "react-bootstrap";

export default function Recipe(props) {
    return <div>
        <p>I am a recipe!</p>
    </div>
}